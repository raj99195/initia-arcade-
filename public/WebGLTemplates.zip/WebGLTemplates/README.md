# InitiaArcade WebGL Template

Branded Unity WebGL template for games published on the InitiaArcade platform.

---

## Installation

1. Copy the `InitiaArcade` folder to your Unity project:

```
YourUnityProject/
└── Assets/
    └── WebGLTemplates/
        └── InitiaArcade/      ← paste here
            ├── index.html
            ├── arcade-sdk.js
            └── thumbnail.txt
```

2. In Unity, go to:
   **Edit → Project Settings → Player → Resolution and Presentation**
   Set **WebGL Template** to **InitiaArcade**

3. Build your game:
   **File → Build Settings → WebGL → Build**

---

## SDK Usage (C#)

Add these calls in your game scripts:

```csharp
// On game start
Application.ExternalCall("arcade_init", "YOUR_GAME_ID");

// During gameplay (real-time score)
Application.ExternalCall("arcade_updateScore", score);

// On game over (submits score on-chain)
Application.ExternalCall("arcade_gameOver", finalScore);

// Award tokens for in-game actions
Application.ExternalCall("arcade_earnTokens", 50);

// In-game shop purchase
Application.ExternalCall("arcade_buyItem", "sword_001", 100);

// Unlock achievement
Application.ExternalCall("arcade_unlockAchievement", "first_kill");

// Level complete
Application.ExternalCall("arcade_levelComplete", 3, score);
```

Get your Game ID from the platform after submitting your game at:
https://initia-arcade.vercel.app/publish

---

## SDK Methods Reference

| Method | Description |
|--------|-------------|
| `arcade_init(gameId)` | Initialize SDK — call once on Start() |
| `arcade_updateScore(score)` | Real-time score update (no blockchain tx) |
| `arcade_gameOver(score)` | Submit final score on-chain |
| `arcade_earnTokens(amount)` | Award ARCADE tokens to player |
| `arcade_buyItem(itemId, price)` | Deduct tokens for shop purchase |
| `arcade_unlockAchievement(id)` | Mint achievement NFT badge |
| `arcade_levelComplete(level, score)` | Record level completion on-chain |
| `arcade_getPlayerInfo(callbackName)` | Get player wallet info |

---

## Platform

- Platform: https://initia-arcade.vercel.app
- Docs: https://initia-arcade.vercel.app/sdk
- Blockchain: Initia (initiation-2 testnet)
- Hackathon: INITIATE Season 1
